// /**
//  * Fine Management Routes
//  * Handles fine calculations and payments
//  */

// const express = require('express');
// const router = express.Router();
// const db = require('../database');
// const { authenticateToken, requireLibrarian } = require('../middleware/auth.middleware');

// /**
//  * GET /api/fines/user/:userId
//  * Get user's fine summary
//  */
// router.get('/user/:userId', authenticateToken, async (req, res) => {
//   try {
//     const userId = parseInt(req.params.userId);

//     if (req.user.role !== 'librarian' && userId !== req.user.id) {
//       return res.status(403).json({ error: 'Access denied' });
//     }

//     const issues = await db.getIssueHistory(userId) || [];

//     const paidIssues = issues.filter(i => i.finePaid);
//     const unpaidIssues = issues.filter(i => (i.fineAmount || 0) > 0 && !i.finePaid);

//     const paidFines = paidIssues.reduce((sum, i) => sum + (i.fineAmount || 0), 0);
//     const unpaidFines = unpaidIssues.reduce((sum, i) => sum + (i.fineAmount || 0), 0);

//     const issuesWithFines = await Promise.all(
//       unpaidIssues.map(async (issue) => {
//         const book = await db.getBookById(issue.bookId);
//         return {
//           issueId: issue.id,
//           bookTitle: book ? book.title : 'Unknown',
//           fineAmount: issue.fineAmount || 0,
//           finePaid: issue.finePaid
//         };
//       })
//     );

//     res.json({
//       totalFines: paidFines + unpaidFines,
//       paidFines,
//       unpaidFines,
//       unpaidIssuesCount: unpaidIssues.length,
//       issuesWithFines
//     });

//   } catch (error) {
//     console.error('FINES ROUTE ERROR:', error);
//     res.status(500).json({ error: 'Failed to fetch fines' });
//   }
// });

// /**
//  * POST /api/fines/:issueId/pay
//  * Pay fine for specific issue
//  */
// router.post('/:issueId/pay', authenticateToken, async (req, res) => {
//   try {
//     const issueId = parseInt(req.params.issueId);
//     const issue = await db.getIssueById(issueId);

//     if (!issue) {
//       return res.status(404).json({ error: 'Issue not found' });
//     }

//     if (req.user.role !== 'librarian' && issue.userId !== req.user.id) {
//       return res.status(403).json({ error: 'Access denied' });
//     }

//     if (issue.finePaid) {
//       return res.status(400).json({ error: 'Fine already paid' });
//     }

//     if (!issue.fineAmount || issue.fineAmount === 0) {
//       return res.status(400).json({ error: 'No fine to pay' });
//     }

//     await db.updateIssue(issueId, { finePaid: true });

//     res.json({
//       message: 'Fine paid successfully',
//       amountPaid: issue.fineAmount
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Failed to process payment' });
//   }
// });

// /**
//  * POST /api/fines/user/:userId/pay-all
//  * Pay all unpaid fines for user
//  */
// router.get('/user/:userId', authenticateToken, async (req, res) => {
//   try {
//     const userId = parseInt(req.params.userId);

//     if (req.user.role !== 'librarian' && userId !== req.user.id) {
//       return res.status(403).json({ error: 'Access denied' });
//     }

//     const issues = await db.getIssueHistory(userId);

//     const paidIssues = issues.filter(i => i.finePaid);
//     const unpaidIssues = issues.filter(i => i.fineAmount > 0 && !i.finePaid);

//     const paidFines = paidIssues.reduce((sum, i) => sum + (i.fineAmount || 0), 0);
//     const unpaidFines = unpaidIssues.reduce((sum, i) => sum + (i.fineAmount || 0), 0);

//     const enrichedUnpaid = await Promise.all(
//       unpaidIssues.map(async (issue) => {
//         const book = await db.getBookById(issue.bookId);
//         return {
//           issueId: issue.id,
//           bookTitle: book ? book.title : 'Unknown',
//           fineAmount: issue.fineAmount,
//           finePaid: issue.finePaid
//         };
//       })
//     );

//     res.json({
//       totalFines: paidFines + unpaidFines,
//       paidFines,
//       unpaidFines,
//       unpaidIssuesCount: unpaidIssues.length,
//       issuesWithFines: enrichedUnpaid
//     });

//   } catch (error) {
//     console.error(error);
//     res.status(500).json({ error: 'Failed to fetch fines' });
//   }
// });

// /**
//  * GET /api/fines/calculate/:issueId
//  * Calculate fine for an issue (preview)
//  */
// router.get('/calculate/:issueId', authenticateToken, async (req, res) => {
//   try {
//     const issueId = parseInt(req.params.issueId);
//     const issue = await db.getIssueById(issueId);
    
//     if (!issue) {
//       return res.status(404).json({ error: 'Issue not found' });
//     }
    
//     // Check access: user can only see own fines
//     if (req.user.role !== 'librarian' && issue.userId !== req.user.id) {
//       return res.status(403).json({ error: 'Access denied' });
//     }
    
//     const fine = await db.calculateFine(issueId);
//     const config = await db.getConfig();
    
//     // Calculate overdue days
//     const now = new Date();
//     const dueDate = new Date(issue.dueDate);
//     const gracePeriod = config.fines.gracePeriodDays;
//     const effectiveDueDate = new Date(dueDate);
//     effectiveDueDate.setDate(effectiveDueDate.getDate() + gracePeriod);
    
//     let overdueDays = 0;
//     if (now > effectiveDueDate) {
//       overdueDays = Math.ceil((now - effectiveDueDate) / (1000 * 60 * 60 * 24));
//     }
    
//     res.json({
//       issueId: issue.id,
//       dueDate: issue.dueDate,
//       gracePeriodDays: gracePeriod,
//       overdueDays: Math.max(0, overdueDays),
//       finePerDay: config.fines.perDayRate,
//       calculatedFine: fine,
//       maxFinePerBook: config.fines.maxFinePerBook,
//       isOverdue: fine > 0,
//       status: issue.status
//     });
    
//   } catch (error) {
//     res.status(500).json({ error: 'Failed to calculate fine' });
//   }
// });

// /**
//  * GET /api/fines/report
//  * Get fines report (Librarian only)
//  */
// router.get('/report', authenticateToken, requireLibrarian, async (req, res) => {
//   try {
//     const users = await db.getAllUsers();
//     const allIssues = await db.getAllIssues();
    
//     const usersWithFines = [];
//     let totalUnpaidFines = 0;
//     let totalPaidFines = 0;
    
//     for (const user of users) {
//       if (user.totalFines > 0 || user.paidFines > 0) {
//         const userIssues = allIssues.filter(i => i.userId === user.id);
//         const unpaidIssues = userIssues.filter(i => i.fineAmount > 0 && !i.finePaid);
        
//         usersWithFines.push({
//           userId: user.id,
//           username: user.username,
//           fullName: user.fullName,
//           unpaidFines: user.totalFines,
//           paidFines: user.paidFines,
//           unpaidIssuesCount: unpaidIssues.length
//         });
        
//         totalUnpaidFines += user.totalFines;
//         totalPaidFines += user.paidFines;
//       }
//     }
    
//     res.json({
//       summary: {
//         totalUnpaidFines,
//         totalPaidFines,
//         usersWithUnpaidFines: usersWithFines.filter(u => u.unpaidFines > 0).length,
//         totalUsersWithFines: usersWithFines.length
//       },
//       users: usersWithFines
//     });
    
//   } catch (error) {
//     res.status(500).json({ error: 'Failed to generate fines report' });
//   }
// });

// module.exports = router;



/**
 * Fine Management Routes
 * Handles fine calculations and payments
 */
 
const express = require('express');
const router = express.Router();
const db = require('../database');
const { authenticateToken, requireLibrarian } = require('../middleware/auth.middleware');
 
/**
 * GET /api/fines/user/:userId
 * Get user's fine summary
 */
router.get('/user/:userId', authenticateToken, async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);

    // 1. Access Control
    if (req.user.role !== 'librarian' && userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const user = await db.getUserById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // 2. Fetch all historical and active issues
    const allIssues = await db.getIssueHistory(userId) || [];

    // 3. Process Live Fines for Unpaid/Active issues
    const enrichedUnpaidIssues = await Promise.all(
      allIssues
        .filter(issue => !issue.finePaid) // Only look at unpaid items
        .map(async (issue) => {
          // Calculate the current fine (live) if not already set on return
          const currentFine = issue.status === 'returned' 
            ? (issue.fineAmount || 0) 
            : await db.calculateFine(issue.id);

          // Only return issues that actually have a fine amount > 0
          if (currentFine <= 0) return null;

          const book = await db.getBookById(issue.bookId);
          return {
            issueId: issue.id,
            bookId: issue.bookId,
            bookTitle: book ? book.title : 'Unknown',
            fineAmount: currentFine,
            finePaid: false,
            status: issue.status,
            dueDate: issue.dueDate
          };
        })
    );

    // Filter out the nulls (issues with no fines)
    const unpaidIssues = enrichedUnpaidIssues.filter(i => i !== null);

    // 4. Calculate total balance dynamically
    // Note: user.totalFines stores fines from already returned books
    const totalPendingFines = unpaidIssues.reduce((sum, i) => sum + i.fineAmount, 0);

    res.json({
      fines: unpaidIssues, // Matches your Fine[] interface
      totalFines: totalPendingFines + user.paidFines, // Lifetime accrued
      paidFines: user.paidFines,
      pendingFines: totalPendingFines // This maps to your FinesResponse interface
    });

  } catch (error) {
    console.error('FINES_ROUTE_ERROR:', error);
    res.status(500).json({ error: 'Failed to fetch fine summary' });
  }
});
/**
 * POST /api/fines/:issueId/pay
 * Pay fine for specific issue
 */router.get('/user/:userId', authenticateToken, async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);

    if (req.user.role !== 'librarian' && userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const user = await db.getUserById(userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const allIssues = await db.getIssueHistory(userId) || [];

    const enrichedUnpaidIssues = await Promise.all(
      allIssues
        .filter(issue => !issue.finePaid)
        .map(async (issue) => {
          // Check live fine if not already recorded
          const currentFine = issue.status === 'returned' 
            ? (issue.fineAmount || 0) 
            : await db.calculateFine(issue.id);

          if (currentFine <= 0) return null;

          const book = await db.getBookById(issue.bookId);
          return {
            issueId: issue.id,
            bookId: issue.bookId,
            bookTitle: book ? book.title : 'Unknown',
            fineAmount: currentFine,
            finePaid: false,
            status: issue.status,
            dueDate: issue.dueDate
          };
        })
    );

    const unpaidIssues = enrichedUnpaidIssues.filter(i => i !== null);
    const totalPendingFines = unpaidIssues.reduce((sum, i) => sum + i.fineAmount, 0);

    res.json({
      fines: unpaidIssues,
      totalFines: totalPendingFines + user.paidFines,
      paidFines: user.paidFines,
      pendingFines: totalPendingFines 
    });

  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch fine summary' });
  }
});

/**
 * POST /api/fines/pay/:issueId
 * Manual payment for a specific issue
 */
router.post('/pay/:issueId', authenticateToken, async (req, res) => {
  try {
    const issueId = parseInt(req.params.issueId);
    const issue = await db.getIssueById(issueId);
    
    if (!issue) return res.status(404).json({ error: 'Issue not found' });
    if (req.user.role !== 'librarian' && issue.userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Determine fine amount (live or recorded)
    const amountToPay = issue.status === 'returned' 
      ? issue.fineAmount 
      : await db.calculateFine(issueId);

    if (amountToPay <= 0) return res.status(400).json({ error: 'No fine to pay' });
    if (issue.finePaid) return res.status(400).json({ error: 'Fine already paid' });

    // Update Issue and User balance
    await db.updateIssue(issueId, { finePaid: true, fineAmount: amountToPay });
    const paymentResult = await db.payUserFine(issue.userId, amountToPay);

    res.json({
      message: 'Fine paid successfully',
      amountPaid: amountToPay,
      remainingFines: paymentResult.remaining
    });
  } catch (error) {
    res.status(500).json({ error: 'Payment failed' });
  }
});


/**
 * POST /api/issues/:issueId/return
 * Handles return and automatic fine clearing
 */
router.post('/return/:issueId', authenticateToken, async (req, res) => {
  try {
    const issueId = parseInt(req.params.issueId);
    const issue = await db.getIssueById(issueId);

    if (!issue) return res.status(404).json({ error: 'Issue not found' });

    // Security check
    if (req.user.role !== 'librarian' && issue.userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // 1. Process the return (this calculates the fine and updates stock)
    const result = await db.processBookReturn(issueId, req.user.username);

    // 2. Logic: If the user "paid" during return (triggered by your frontend confirm)
    // We mark the specific issue fine as paid immediately
    if (result.fine > 0) {
       await db.updateIssue(issueId, { finePaid: true });
       // Also deduct it from the user's total balance so it shows 0
       await db.payUserFine(issue.userId, result.fine);
    }

    res.json({
      message: 'Book returned and fines cleared',
      finePaid: result.fine,
      status: 'returned'
    });

  } catch (error) {
    console.error('RETURN_ERROR:', error);
    res.status(500).json({ error: error.message });
  }
});
 
/**
 * POST /api/fines/user/:userId/pay-all
 * Pay all unpaid fines for user
 */
router.post('/user/:userId/pay-all', authenticateToken, async (req, res) => {
  try {
    const userId = parseInt(req.params.userId);
   
    // Check access: user can only pay own fines
    if (req.user.role !== 'librarian' && userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
   
    const user = await db.getUserById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
   
    if (user.totalFines === 0) {
      return res.status(400).json({ error: 'No outstanding fines' });
    }
   
    // Get all unpaid issues
    const allIssues = await db.getIssueHistory(userId);
    const unpaidIssues = allIssues.filter(issue =>
      issue.fineAmount > 0 && !issue.finePaid
    );
   
    // Mark all as paid
    for (const issue of unpaidIssues) {
      await db.updateIssue(issue.id, { finePaid: true });
    }
   
    // Pay all fines
    const totalAmount = user.totalFines;
    const paymentResult = await db.payUserFine(userId, totalAmount);
   
    res.json({
      message: 'All fines paid successfully',
      amountPaid: totalAmount,
      issuesPaid: unpaidIssues.length,
      remainingFines: paymentResult.remaining
    });
   
  } catch (error) {
    res.status(500).json({ error: 'Failed to process payment' });
  }
});
 
/**
 * GET /api/fines/calculate/:issueId
 * Calculate fine for an issue (preview)
 */
router.get('/calculate/:issueId', authenticateToken, async (req, res) => {
  try {
    const issueId = parseInt(req.params.issueId);
    const issue = await db.getIssueById(issueId);
   
    if (!issue) {
      return res.status(404).json({ error: 'Issue not found' });
    }
   
    // Check access: user can only see own fines
    if (req.user.role !== 'librarian' && issue.userId !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
   
    const fine = await db.calculateFine(issueId);
    const config = await db.getConfig();
   
    // Calculate overdue days
    const now = new Date();
    const dueDate = new Date(issue.dueDate);
    const gracePeriod = config.fines.gracePeriodDays;
    const effectiveDueDate = new Date(dueDate);
    effectiveDueDate.setDate(effectiveDueDate.getDate() + gracePeriod);
   
    let overdueDays = 0;
    if (now > effectiveDueDate) {
      overdueDays = Math.ceil((now - effectiveDueDate) / (1000 * 60 * 60 * 24));
    }
   
    res.json({
      issueId: issue.id,
      dueDate: issue.dueDate,
      gracePeriodDays: gracePeriod,
      overdueDays: Math.max(0, overdueDays),
      finePerDay: config.fines.perDayRate,
      calculatedFine: fine,
      maxFinePerBook: config.fines.maxFinePerBook,
      isOverdue: fine > 0,
      status: issue.status
    });
   
  } catch (error) {
    res.status(500).json({ error: 'Failed to calculate fine' });
  }
});
 
/**
 * GET /api/fines/report
 * Get fines report (Librarian only)
 */
router.get('/report', authenticateToken, requireLibrarian, async (req, res) => {
  try {
    const users = await db.getAllUsers();
    const allIssues = await db.getAllIssues();
   
    const usersWithFines = [];
    let totalUnpaidFines = 0;
    let totalPaidFines = 0;
   
    for (const user of users) {
      if (user.totalFines > 0 || user.paidFines > 0) {
        const userIssues = allIssues.filter(i => i.userId === user.id);
        const unpaidIssues = userIssues.filter(i => i.fineAmount > 0 && !i.finePaid);
       
        usersWithFines.push({
          userId: user.id,
          username: user.username,
          fullName: user.fullName,
          unpaidFines: user.totalFines,
          paidFines: user.paidFines,
          unpaidIssuesCount: unpaidIssues.length
        });
       
        totalUnpaidFines += user.totalFines;
        totalPaidFines += user.paidFines;
      }
    }
   
    res.json({
      summary: {
        totalUnpaidFines,
        totalPaidFines,
        usersWithUnpaidFines: usersWithFines.filter(u => u.unpaidFines > 0).length,
        totalUsersWithFines: usersWithFines.length
      },
      users: usersWithFines
    });
   
  } catch (error) {
    res.status(500).json({ error: 'Failed to generate fines report' });
  }
});
 
module.exports = router;
 